<?php
session_start();
if (!isset($_SESSION["user"])) {
  header("Location: e.php");
  exit;
}
$user = $_SESSION["user"];

// ---------- CODE SAVE ----------
if (isset($_POST["code"])) {
  file_put_contents("co.txt", $_POST["code"]);
  exit;
}

// ---------- CHAT SAVE ----------
if (isset($_POST["chat"])) {
  file_put_contents(
    "ch.txt",
    $user . ": " . $_POST["chat"] . "\n",
    FILE_APPEND
  );
  exit;
}

// ---------- CHAT DELETE ----------
if (isset($_POST["clearChat"])) {
  file_put_contents("ch.txt", "");
  exit;
}
?>
<!DOCTYPE html>
<html>
<head>
<title>CodeShare</title>
<style>
body{
  margin:0;
  background:#020617;
  color:#e5e7eb;
  font-family:Consolas;
}
header{
  padding:10px;
  display:flex;
  justify-content:flex-end;
  gap:15px;
}
textarea{
  width:70%;
  height:90vh;
  background:#020617;
  color:#22d3ee;
  border:none;
  padding:10px;
}
#chat{
  width:30%;
  background:#0f172a;
  display:flex;
  flex-direction:column;
}
#messages{
  flex:1;
  overflow:auto;
  padding:10px;
}
#msg{
  padding:10px;
  border:none;
}
.icon{
  cursor:pointer;
  color:#f87171;
}
</style>
</head>
<body>

<header>
  <div>👤 <?php echo $user; ?></div>
  <div class="icon" onclick="clearChat()">🗑</div>
  <a href="o.php" style="color:#f87171">Logout</a>
</header>

<div style="display:flex">
  <textarea id="editor" placeholder="Shared code..."></textarea>

  <div id="chat">
    <div id="messages"></div>
    <input id="msg" placeholder="Type message & Enter">
  </div>
</div>

<script>
const editor = document.getElementById("editor");
const messages = document.getElementById("messages");
const msg = document.getElementById("msg");
let typing=false;

// -------- CODE SHARE --------
function loadCode(){
  fetch("co.txt").then(r=>r.text()).then(d=>{
    if(!typing) editor.value=d;
  });
}
loadCode();
setInterval(loadCode,1000);

editor.oninput=()=>{
  typing=true;
  fetch("",{method:"POST",headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body:"code="+encodeURIComponent(editor.value)});
  setTimeout(()=>typing=false,800);
};

// -------- CHAT --------
function loadChat(){
  fetch("ch.txt").then(r=>r.text()).then(d=>{
    messages.innerHTML=d.replace(/\n/g,"<br>");
    messages.scrollTop=messages.scrollHeight;
  });
}
setInterval(loadChat,1000);

msg.addEventListener("keydown",e=>{
  if(e.key==="Enter"){
    fetch("",{method:"POST",headers:{'Content-Type':'application/x-www-form-urlencoded'},
      body:"chat="+encodeURIComponent(msg.value)});
    msg.value="";
  }
});

function clearChat(){
  fetch("",{method:"POST",headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body:"clearChat=1"});
}
</script>

</body>
</html>
