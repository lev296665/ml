<?php
header("Location: i.php");
?>