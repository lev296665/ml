<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

  // 🔒 STATIC USERS LIST
  $USERS = [
    "sys"   => "s3",
    "root"=> "r4",
    "error"=> "e5",
    "hi"=> "h2",
    "cache"=> "c5"
  ];

  $u = $_POST["username"] ?? "";
  $p = $_POST["password"] ?? "";

  // ✅ SIMPLE STATIC CHECK
  if (isset($USERS[$u]) && $USERS[$u] === $p) {
    $_SESSION["user"] = $u;   // store actual name
    header("Location: i.php");
    exit;
  }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Loading...</title>
<style>
body{
  margin:0;
  background:#020617;
  color:#94a3b8;
  font-family:Arial;
  height:100vh;
  overflow:hidden;
}

/* Fake Screen */
#fakeScreen{
  height:100vh;
  display:flex;
  justify-content:center;
  align-items:center;
  flex-direction:column;
  font-size:14px;
}

/* LEFT SIDE SECRET AREA */
#leftSecret{
  position:fixed;
  left:0;
  top:0;
  width:60px;     /* clickable width */
  height:100vh;
  cursor:pointer;
}
#rightTopSecret{
  position: fixed;
  top: 0;
  right: 0;
  width: 60px;     /* clickable width */
  height: 60px;    /* clickable height */
  cursor: pointer;
}

/* Real Login */
#loginBox{
  display:none;
  position:absolute;
  top:50%;
  left:50%;
  transform:translate(-50%,-50%);
  background:#0f172a;
  padding:30px;
  color:white;
}

input,button{
  width:100%;
  padding:10px;
  margin-top:10px;
}

button{
  background:#22d3ee;
  border:none;
}
</style>
</head>

<body>

<!-- Fake Error / Loader -->
<div id="fakeScreen">
  <div>Loading resources...</div>
  <div style="margin-top:8px;">ERR_EMPTY_RESPONSE</div>
</div>

<!-- SECRET LEFT SIDE CLICK AREA -->
<div id="rightTopSecret" onclick="showLogin()"></div>


<!-- REAL LOGIN -->
<div id="loginBox">
  <form method="post">
    <h3>Restricted Access</h3>
    <input name="username" placeholder="Username" required>
    <input name="password" type="password" placeholder="Password" required>
    <button>Login</button>
  </form>
</div>

<script>
function showLogin(){
  document.getElementById("fakeScreen").style.display="none";
  document.getElementById("loginBox").style.display="block";
}
</script>

</body>
</html>
